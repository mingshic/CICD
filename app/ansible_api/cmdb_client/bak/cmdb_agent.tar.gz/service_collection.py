#!/usr/bin/python

import os


def proccess_port():
    if os.path.exists("/usr/sbin/ss"):
        ss = os.popen("/usr/sbin/ss -antl |awk -F ' ' '{print $4}'")
    elif os.path.exists("/bin/ss"):
        ss = os.popen("/bin/ss -antl |awk -F ' ' '{print $4}'")
    ports = ss.read().strip().split("\n")
    _port = []
    
    for port in range(len(ports)):
        port_ = ports[port].split(":")[-1]
        if port_.isdigit():
            _port.append(port_)
    return _port


def proccess():
    infos = {}
    if os.path.exists("/usr/sbin/lsof"):
        where = "/usr/sbin/lsof"
    elif os.path.exists("/bin/lsof"):
        where = "/bin/lsof"
    portlist = proccess_port()
    for port in portlist:
        info = os.popen("%s -i:%s |awk -F ' ' '{print $1,$9}'|grep -vi name|grep -vi ssh|uniq" % (where, port)).read().strip()
        if info != "":  
            infos.update({port: info})
    return infos

    
