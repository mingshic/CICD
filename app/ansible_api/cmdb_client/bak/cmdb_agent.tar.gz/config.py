#!/usr/bin/python

url = "http://192.168.52.143:5000/machineDB"
