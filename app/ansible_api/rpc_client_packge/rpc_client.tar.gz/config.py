#-*- coding: utf-8 -*-


RPC = {
    "rpc_server": "192.168.52.143",
    "rpc_port": "50051",
}



